﻿namespace schummeleditor_cshp13c
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.punkteTextBox1 = new System.Windows.Forms.TextBox();
            this.nameTextBox1 = new System.Windows.Forms.TextBox();
            this.nameTextBox2 = new System.Windows.Forms.TextBox();
            this.punkteTextBox2 = new System.Windows.Forms.TextBox();
            this.nameTextBox3 = new System.Windows.Forms.TextBox();
            this.punkteTextBox3 = new System.Windows.Forms.TextBox();
            this.nameTextBox6 = new System.Windows.Forms.TextBox();
            this.punkteTextBox6 = new System.Windows.Forms.TextBox();
            this.nameTextBox5 = new System.Windows.Forms.TextBox();
            this.punkteTextBox5 = new System.Windows.Forms.TextBox();
            this.nameTextBox4 = new System.Windows.Forms.TextBox();
            this.punkteTextBox4 = new System.Windows.Forms.TextBox();
            this.nameTextBox9 = new System.Windows.Forms.TextBox();
            this.punkteTextBox9 = new System.Windows.Forms.TextBox();
            this.nameTextBox8 = new System.Windows.Forms.TextBox();
            this.punkteTextBox8 = new System.Windows.Forms.TextBox();
            this.nameTextBox7 = new System.Windows.Forms.TextBox();
            this.punkteTextBox7 = new System.Windows.Forms.TextBox();
            this.nameTextBox10 = new System.Windows.Forms.TextBox();
            this.punkteTextBox10 = new System.Windows.Forms.TextBox();
            this.lesenButton = new System.Windows.Forms.Button();
            this.speichernButton = new System.Windows.Forms.Button();
            this.beendenButton = new System.Windows.Forms.Button();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Punkte";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(153, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Name";
            // 
            // punkteTextBox1
            // 
            this.punkteTextBox1.Location = new System.Drawing.Point(16, 30);
            this.punkteTextBox1.Name = "punkteTextBox1";
            this.punkteTextBox1.Size = new System.Drawing.Size(100, 20);
            this.punkteTextBox1.TabIndex = 2;
            // 
            // nameTextBox1
            // 
            this.nameTextBox1.Location = new System.Drawing.Point(156, 30);
            this.nameTextBox1.Name = "nameTextBox1";
            this.nameTextBox1.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox1.TabIndex = 3;
            // 
            // nameTextBox2
            // 
            this.nameTextBox2.Location = new System.Drawing.Point(156, 56);
            this.nameTextBox2.Name = "nameTextBox2";
            this.nameTextBox2.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox2.TabIndex = 5;
            // 
            // punkteTextBox2
            // 
            this.punkteTextBox2.Location = new System.Drawing.Point(16, 56);
            this.punkteTextBox2.Name = "punkteTextBox2";
            this.punkteTextBox2.Size = new System.Drawing.Size(100, 20);
            this.punkteTextBox2.TabIndex = 4;
            // 
            // nameTextBox3
            // 
            this.nameTextBox3.Location = new System.Drawing.Point(156, 82);
            this.nameTextBox3.Name = "nameTextBox3";
            this.nameTextBox3.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox3.TabIndex = 7;
            // 
            // punkteTextBox3
            // 
            this.punkteTextBox3.Location = new System.Drawing.Point(16, 82);
            this.punkteTextBox3.Name = "punkteTextBox3";
            this.punkteTextBox3.Size = new System.Drawing.Size(100, 20);
            this.punkteTextBox3.TabIndex = 6;
            // 
            // nameTextBox6
            // 
            this.nameTextBox6.Location = new System.Drawing.Point(156, 160);
            this.nameTextBox6.Name = "nameTextBox6";
            this.nameTextBox6.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox6.TabIndex = 13;
            // 
            // punkteTextBox6
            // 
            this.punkteTextBox6.Location = new System.Drawing.Point(16, 160);
            this.punkteTextBox6.Name = "punkteTextBox6";
            this.punkteTextBox6.Size = new System.Drawing.Size(100, 20);
            this.punkteTextBox6.TabIndex = 12;
            // 
            // nameTextBox5
            // 
            this.nameTextBox5.Location = new System.Drawing.Point(156, 134);
            this.nameTextBox5.Name = "nameTextBox5";
            this.nameTextBox5.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox5.TabIndex = 11;
            // 
            // punkteTextBox5
            // 
            this.punkteTextBox5.Location = new System.Drawing.Point(16, 134);
            this.punkteTextBox5.Name = "punkteTextBox5";
            this.punkteTextBox5.Size = new System.Drawing.Size(100, 20);
            this.punkteTextBox5.TabIndex = 10;
            // 
            // nameTextBox4
            // 
            this.nameTextBox4.Location = new System.Drawing.Point(156, 108);
            this.nameTextBox4.Name = "nameTextBox4";
            this.nameTextBox4.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox4.TabIndex = 9;
            // 
            // punkteTextBox4
            // 
            this.punkteTextBox4.Location = new System.Drawing.Point(16, 108);
            this.punkteTextBox4.Name = "punkteTextBox4";
            this.punkteTextBox4.Size = new System.Drawing.Size(100, 20);
            this.punkteTextBox4.TabIndex = 8;
            // 
            // nameTextBox9
            // 
            this.nameTextBox9.Location = new System.Drawing.Point(156, 238);
            this.nameTextBox9.Name = "nameTextBox9";
            this.nameTextBox9.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox9.TabIndex = 19;
            // 
            // punkteTextBox9
            // 
            this.punkteTextBox9.Location = new System.Drawing.Point(16, 238);
            this.punkteTextBox9.Name = "punkteTextBox9";
            this.punkteTextBox9.Size = new System.Drawing.Size(100, 20);
            this.punkteTextBox9.TabIndex = 18;
            // 
            // nameTextBox8
            // 
            this.nameTextBox8.Location = new System.Drawing.Point(156, 212);
            this.nameTextBox8.Name = "nameTextBox8";
            this.nameTextBox8.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox8.TabIndex = 17;
            // 
            // punkteTextBox8
            // 
            this.punkteTextBox8.Location = new System.Drawing.Point(16, 212);
            this.punkteTextBox8.Name = "punkteTextBox8";
            this.punkteTextBox8.Size = new System.Drawing.Size(100, 20);
            this.punkteTextBox8.TabIndex = 16;
            // 
            // nameTextBox7
            // 
            this.nameTextBox7.Location = new System.Drawing.Point(156, 186);
            this.nameTextBox7.Name = "nameTextBox7";
            this.nameTextBox7.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox7.TabIndex = 15;
            // 
            // punkteTextBox7
            // 
            this.punkteTextBox7.Location = new System.Drawing.Point(16, 186);
            this.punkteTextBox7.Name = "punkteTextBox7";
            this.punkteTextBox7.Size = new System.Drawing.Size(100, 20);
            this.punkteTextBox7.TabIndex = 14;
            // 
            // nameTextBox10
            // 
            this.nameTextBox10.Location = new System.Drawing.Point(156, 264);
            this.nameTextBox10.Name = "nameTextBox10";
            this.nameTextBox10.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox10.TabIndex = 21;
            // 
            // punkteTextBox10
            // 
            this.punkteTextBox10.Location = new System.Drawing.Point(16, 264);
            this.punkteTextBox10.Name = "punkteTextBox10";
            this.punkteTextBox10.Size = new System.Drawing.Size(100, 20);
            this.punkteTextBox10.TabIndex = 20;
            // 
            // lesenButton
            // 
            this.lesenButton.Location = new System.Drawing.Point(299, 26);
            this.lesenButton.Name = "lesenButton";
            this.lesenButton.Size = new System.Drawing.Size(75, 23);
            this.lesenButton.TabIndex = 22;
            this.lesenButton.Text = "Lesen";
            this.lesenButton.UseVisualStyleBackColor = true;
            this.lesenButton.Click += new System.EventHandler(this.lesenButton_Click);
            // 
            // speichernButton
            // 
            this.speichernButton.Location = new System.Drawing.Point(299, 56);
            this.speichernButton.Name = "speichernButton";
            this.speichernButton.Size = new System.Drawing.Size(75, 23);
            this.speichernButton.TabIndex = 23;
            this.speichernButton.Text = "Speichern";
            this.speichernButton.UseVisualStyleBackColor = true;
            this.speichernButton.Click += new System.EventHandler(this.speichernButton_Click);
            // 
            // beendenButton
            // 
            this.beendenButton.Location = new System.Drawing.Point(299, 108);
            this.beendenButton.Name = "beendenButton";
            this.beendenButton.Size = new System.Drawing.Size(75, 23);
            this.beendenButton.TabIndex = 24;
            this.beendenButton.Text = "Beenden";
            this.beendenButton.UseVisualStyleBackColor = true;
            this.beendenButton.Click += new System.EventHandler(this.beendenButton_Click);
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(387, 295);
            this.Controls.Add(this.beendenButton);
            this.Controls.Add(this.speichernButton);
            this.Controls.Add(this.lesenButton);
            this.Controls.Add(this.nameTextBox10);
            this.Controls.Add(this.punkteTextBox10);
            this.Controls.Add(this.nameTextBox9);
            this.Controls.Add(this.punkteTextBox9);
            this.Controls.Add(this.nameTextBox8);
            this.Controls.Add(this.punkteTextBox8);
            this.Controls.Add(this.nameTextBox7);
            this.Controls.Add(this.punkteTextBox7);
            this.Controls.Add(this.nameTextBox6);
            this.Controls.Add(this.punkteTextBox6);
            this.Controls.Add(this.nameTextBox5);
            this.Controls.Add(this.punkteTextBox5);
            this.Controls.Add(this.nameTextBox4);
            this.Controls.Add(this.punkteTextBox4);
            this.Controls.Add(this.nameTextBox3);
            this.Controls.Add(this.punkteTextBox3);
            this.Controls.Add(this.nameTextBox2);
            this.Controls.Add(this.punkteTextBox2);
            this.Controls.Add(this.nameTextBox1);
            this.Controls.Add(this.punkteTextBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Schummeleditor";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox nameTextBox1;
        public System.Windows.Forms.TextBox nameTextBox2;
        public System.Windows.Forms.TextBox punkteTextBox2;
        public System.Windows.Forms.TextBox nameTextBox3;
        public System.Windows.Forms.TextBox punkteTextBox3;
        public System.Windows.Forms.TextBox nameTextBox6;
        public System.Windows.Forms.TextBox punkteTextBox6;
        public System.Windows.Forms.TextBox nameTextBox5;
        public System.Windows.Forms.TextBox punkteTextBox5;
        public System.Windows.Forms.TextBox nameTextBox4;
        public System.Windows.Forms.TextBox punkteTextBox4;
        public System.Windows.Forms.TextBox nameTextBox9;
        public System.Windows.Forms.TextBox punkteTextBox9;
        public System.Windows.Forms.TextBox nameTextBox8;
        public System.Windows.Forms.TextBox punkteTextBox8;
        public System.Windows.Forms.TextBox nameTextBox7;
        public System.Windows.Forms.TextBox punkteTextBox7;
        public System.Windows.Forms.TextBox nameTextBox10;
        public System.Windows.Forms.TextBox punkteTextBox10;
        private System.Windows.Forms.Button lesenButton;
        private System.Windows.Forms.Button speichernButton;
        private System.Windows.Forms.Button beendenButton;
        public System.Windows.Forms.TextBox punkteTextBox1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
    }
}

